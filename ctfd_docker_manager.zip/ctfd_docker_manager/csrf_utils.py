# from flask import request, current_app
# from flask_wtf import CSRFProtect

# csrf = CSRFProtect()

# def csrf_exempt(view):
#     view._exclude_from_csrf = True
#     return view

# # Monkey-patch csrf.protect to skip views with the exempt flag
# original_protect = csrf.protect
# def patched_protect():
#     if request.endpoint:
#         view_func = current_app.view_functions.get(request.endpoint)
#         if getattr(view_func, '_exclude_from_csrf', False):
#             return
#     return original_protect()

# csrf.protect = patched_protect
