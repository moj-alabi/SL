# CTFd Docker Management Plugin

A comprehensive Docker container management plugin for CTFd that allows administrators to deploy, manage, and monitor Docker containers directly from the CTFd admin interface.

## Features

### 🚀 Container Management
- **Deploy Containers**: Launch containers from Docker images with custom configurations
- **Lifecycle Control**: Start, stop, and remove containers with a single click
- **Real-time Monitoring**: View container statistics including CPU, memory, and network usage
- **Resource Limits**: Set memory and CPU limits for containers

### 🏗️ Docker Host Support
- **Local Docker**: Connect to local Docker daemon via Unix socket
- **Remote Docker**: Connect to remote Docker hosts via TCP
- **TLS Security**: Support for TLS-secured Docker connections
- **Multi-host**: Manage containers across multiple Docker hosts

### 🎯 Challenge Integration
- **Challenge Mapping**: Link containers to specific CTF challenges
- **Auto-deployment**: Automatically deploy containers when challenges are accessed
- **Port Management**: Configure port mappings for challenge access
- **Environment Variables**: Set challenge-specific environment variables

### 🔧 Admin Interface
- **Dashboard**: Overview of all containers, hosts, and statistics
- **Host Management**: Add, configure, and monitor Docker hosts
- **Container Console**: Deploy and manage containers with an intuitive UI
- **Challenge Linking**: Map Docker images to CTF challenges

## Installation

1. **Download the Plugin**
   ```bash
   cd /path/to/ctfd/CTFd/plugins/
   git clone <repository-url> ctfd_docker_manager
   ```

2. **Install Dependencies**
   ```bash
   cd ctfd_docker_manager
   pip install -r requirements.txt
   ```

3. **Configure CTFd**
   Add the following to your CTFd configuration:
   ```python
   # config.py or environment variables
   DOCKER_DEFAULT_HOST = 'unix:///var/run/docker.sock'  # or tcp://host:port
   DOCKER_NETWORK_NAME = 'ctfd_challenges'
   DOCKER_CONTAINER_PREFIX = 'ctfd_'
   DOCKER_MEMORY_LIMIT = '512m'
   DOCKER_CPU_LIMIT = '0.5'
   ```

4. **Restart CTFd**
   ```bash
   # Restart your CTFd instance
   systemctl restart ctfd  # or your preferred method
   ```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DOCKER_DEFAULT_HOST` | Default Docker host connection | `unix:///var/run/docker.sock` |
| `DOCKER_TLS_VERIFY` | Enable TLS verification | `False` |
| `DOCKER_CERT_PATH` | Path to TLS certificates | `None` |
| `DOCKER_NETWORK_NAME` | Docker network for challenges | `ctfd_challenges` |
| `DOCKER_CONTAINER_PREFIX` | Prefix for container names | `ctfd_` |
| `DOCKER_AUTO_REMOVE` | Auto-remove stopped containers | `True` |
| `DOCKER_MEMORY_LIMIT` | Default memory limit | `512m` |
| `DOCKER_CPU_LIMIT` | Default CPU limit | `0.5` |

### Docker Host Setup

#### Local Docker (Unix Socket)
```python
DOCKER_DEFAULT_HOST = 'unix:///var/run/docker.sock'
```

#### Remote Docker (TCP)
```python
DOCKER_DEFAULT_HOST = 'tcp://192.168.1.100:2376'
DOCKER_TLS_VERIFY = True
DOCKER_CERT_PATH = '/path/to/certs'
```

#### Docker Swarm
```python
DOCKER_DEFAULT_HOST = 'tcp://swarm-manager:2377'
```

## Usage

### 1. Access the Plugin
Navigate to **Admin Panel → Docker Management** in your CTFd interface.

### 2. Add Docker Hosts
1. Go to **Docker Hosts** tab
2. Click **Add Docker Host**
3. Configure connection details:
   - **Name**: Friendly name for the host
   - **Host**: Connection string (unix socket or TCP)
   - **TLS Settings**: Enable if using TLS
   - **Certificate Paths**: Provide cert, key, and CA paths if using TLS

### 3. Deploy Containers
1. Go to **Containers** tab
2. Click **Deploy New Container**
3. Configure container settings:
   - **Name**: Unique container name
   - **Image**: Docker image to deploy
   - **Host**: Target Docker host
   - **Ports**: Port mappings (host:container)
   - **Environment**: Environment variables
   - **Resources**: Memory and CPU limits
   - **Challenge Link**: Optional challenge association

### 4. Manage Containers
- **Start/Stop**: Control container lifecycle
- **Monitor**: View real-time statistics
- **Remove**: Delete containers and cleanup

### 5. Link to Challenges
1. Go to **Challenge Mapping** tab
2. Create challenge-container associations
3. Configure auto-deployment settings
4. Set default container parameters

## API Endpoints

The plugin provides REST API endpoints for programmatic access:

### Container Operations
- `POST /api/docker/containers/{id}/start` - Start container
- `POST /api/docker/containers/{id}/stop` - Stop container
- `DELETE /api/docker/containers/{id}/remove` - Remove container
- `GET /api/docker/containers/{id}/stats` - Get container stats

### Host Operations
- `GET /api/docker/hosts/{id}/info` - Get host information
- `GET /api/docker/hosts/{id}/containers` - List host containers

## Security Considerations

### 1. Docker Socket Access
- **Local**: Ensure CTFd process has access to Docker socket
- **Remote**: Use TLS authentication for remote connections
- **Permissions**: Limit Docker daemon permissions

### 2. Container Security
- **Resource Limits**: Always set memory and CPU limits
- **Network Isolation**: Use dedicated Docker networks
- **Image Scanning**: Scan Docker images for vulnerabilities

### 3. Access Control
- **Admin Only**: Plugin restricted to CTFd administrators
- **Audit Logging**: All actions are logged for security audit
- **API Authentication**: API endpoints require admin authentication

## Troubleshooting

### Common Issues

#### 1. Docker Connection Failed
```
Error: Cannot connect to Docker daemon
```
**Solution**: Check Docker daemon status and connection settings

#### 2. Permission Denied
```
Error: Permission denied accessing Docker socket
```
**Solution**: Add CTFd user to docker group or adjust socket permissions

#### 3. Container Start Failed
```
Error: Failed to start container
```
**Solution**: Check image availability, port conflicts, and resource limits

#### 4. TLS Certificate Error
```
Error: TLS handshake failed
```
**Solution**: Verify certificate paths and TLS configuration

### Debug Mode
Enable debug logging by setting:
```python
import logging
logging.getLogger('ctfd_docker_manager').setLevel(logging.DEBUG)
```

### Log Files
Check CTFd logs for Docker manager entries:
```bash
tail -f /var/log/ctfd/ctfd.log | grep docker_manager
```

## Development

### Plugin Structure
```
ctfd_docker_manager/
├── __init__.py              # Plugin initialization
├── models.py                # Database models
├── views.py                 # Flask routes and views
├── docker_manager.py        # Docker operations
├── config.py                # Configuration management
├── templates/               # Jinja2 templates
│   ├── base.html
│   ├── docker_dashboard.html
│   ├── docker_containers.html
│   └── deploy_container.html
├── assets/                  # Static assets
│   ├── css/
│   └── js/
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

### Testing
```bash
# Run tests
python -m pytest tests/

# Test Docker connection
python -c "from docker_manager import DockerManager; dm = DockerManager(); print(dm.get_host_info())"
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and bug reports:
- **GitHub Issues**: Create an issue in the repository
- **CTFd Discord**: Join the CTFd community discord
- **Documentation**: Check CTFd plugin documentation

## Roadmap

### Upcoming Features
- [ ] Docker Compose support
- [ ] Container templates
- [ ] Advanced networking configuration
- [ ] Container clustering
- [ ] Automated backups
- [ ] Performance metrics dashboard
- [ ] Container logs viewer
- [ ] Image vulnerability scanning

### Version History
- **v1.0.0**: Initial release with basic container management
- **v1.1.0**: Added multi-host support and TLS
- **v1.2.0**: Challenge integration and auto-deployment