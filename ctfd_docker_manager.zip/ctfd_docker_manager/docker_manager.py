import os
import json
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from CTFd.models import db
from .models import DockerHost, DockerContainer
from .config import DockerConfig

logger = logging.getLogger(__name__)

# Enable simulation mode via env variable
SIMULATE = os.environ.get("SIMULATE_DOCKER", "false").lower() == "true"

if not SIMULATE:
    import docker


class DockerManager:
    """Manages Docker operations for CTFd challenges"""

    def __init__(self, host_config: DockerHost = None):
        self.host_config = host_config
        self.client = None
        if not SIMULATE:
            self._connect()

    def _connect(self):
        """Connect to Docker daemon (only if not simulating)"""
        try:
            if self.host_config:
                if self.host_config.tls_enabled:
                    tls_config = docker.tls.TLSConfig(
                        client_cert=(self.host_config.cert_path, self.host_config.key_path),
                        ca_cert=self.host_config.ca_path,
                        verify=True
                    )
                    self.client = docker.DockerClient(base_url=self.host_config.host, tls=tls_config)
                else:
                    self.client = docker.DockerClient(base_url=self.host_config.host)
            else:
                self.client = docker.from_env()

            self.client.ping()
            logger.info(f"Connected to Docker daemon: {self.get_host_info()}")

        except Exception as e:
            logger.error(f"Failed to connect to Docker: {e}")
            self.client = None
            raise

    def get_host_info(self) -> Dict:
        if SIMULATE:
            return {
                "name": "SimulatedDocker",
                "version": "fake-1.0",
                "containers": 0,
                "images": 0,
                "memory": 0,
                "cpus": 1
            }

        try:
            info = self.client.info()
            return {
                "name": info.get("Name", "Unknown"),
                "version": self.client.version()["Version"],
                "containers": info.get("Containers", 0),
                "images": info.get("Images", 0),
                "memory": info.get("MemTotal", 0),
                "cpus": info.get("NCPU", 0)
            }
        except Exception as e:
            logger.error(f"Failed to get host info: {e}")
            return {"error": str(e)}

    def create_network(self, network_name: str = None) -> bool:
        if SIMULATE:
            logger.info("[SIMULATED] Created Docker network")
            return True

        network_name = network_name or DockerConfig.get_network_name()

        try:
            if self.client.networks.list(names=[network_name]):
                return True
            self.client.networks.create(
                network_name,
                driver="bridge",
                options={"com.docker.network.bridge.name": network_name}
            )
            return True
        except Exception as e:
            logger.error(f"Failed to create network: {e}")
            return False

    def deploy_container(self, container_config: DockerContainer) -> Tuple[bool, str]:
        if SIMULATE:
            container_config.container_id = f"simulated-{container_config.name}"
            container_config.status = 'running'
            container_config.started_at = datetime.utcnow()
            logger.info(f"[SIMULATED] Deployed container: {container_config.container_id}")
            return True, container_config.container_id

        try:
            ports = json.loads(container_config.ports or '{}')
            environment = json.loads(container_config.environment or '{}')
            volumes = json.loads(container_config.volumes or '{}')
            container_name = f"{DockerConfig.get_container_prefix()}{container_config.name}"

            container = self.client.containers.run(
                image=container_config.image,
                name=container_name,
                ports=ports,
                environment=environment,
                volumes=volumes,
                network=DockerConfig.get_network_name(),
                mem_limit=container_config.memory_limit or DockerConfig.get_default_limits()['memory'],
                cpu_quota=int(float(container_config.cpu_limit or DockerConfig.get_default_limits()['cpu']) * 100000),
                detach=True,
                remove=False
            )

            container_config.container_id = container.id
            container_config.status = 'running'
            container_config.started_at = datetime.utcnow()

            return True, container.id

        except Exception as e:
            logger.error(f"Failed to deploy container: {e}")
            container_config.status = 'failed'
            return False, str(e)

    def stop_container(self, container_config: DockerContainer) -> Tuple[bool, str]:
        """Stop a running container"""
        if SIMULATE:
            container_config.status = 'stopped'
            container_config.stopped_at = datetime.utcnow()
            logger.info(f"[SIMULATED] Stopped container: {container_config.container_id}")
            try:
                db.session.commit()
                return True, "Container stopped"
            except Exception as e:
                db.session.rollback()
                return False, f"Failed to commit simulated stop: {e}"

        try:
            container = self.client.containers.get(container_config.container_id)
            container.stop(timeout=10)
            container_config.status = 'stopped'
            container_config.stopped_at = datetime.utcnow()
            db.session.commit()
            logger.info(f"Stopped container: {container_config.container_id}")
            return True, "Container stopped"
        except Exception as e:
            db.session.rollback()
            logger.error(f"Failed to stop container: {e}")
            return False, str(e)


    def remove_container(self, container_config: DockerContainer) -> Tuple[bool, str]:
        """Remove a container"""
        if SIMULATE:
            container_config.status = 'removed'
            container_config.stopped_at = datetime.utcnow()
            logger.info(f"[SIMULATED] Removed container: {container_config.container_id}")
            try:
                db.session.commit()
                return True, "Container removed"
            except Exception as e:
                db.session.rollback()
                return False, f"Failed to commit simulated removal: {e}"

        try:
            container = self.client.containers.get(container_config.container_id)
            container.remove(force=True)
            container_config.status = 'removed'
            container_config.stopped_at = datetime.utcnow()
            db.session.commit()
            logger.info(f"Removed container: {container_config.container_id}")
            return True, "Container removed"
        except Exception as e:
            db.session.rollback()
            logger.error(f"Failed to remove container: {e}")
            return False, str(e)

    def get_container_stats(self, container_id: str) -> Dict:
        if SIMULATE:
            return {
                "cpu_percent": 0.5,
                "memory_usage": 10000000,
                "memory_limit": 512000000,
                "memory_percent": 1.95,
                "network_rx": 123456,
                "network_tx": 654321
            }

        try:
            container = self.client.containers.get(container_id)
            stats = container.stats(stream=False)
            cpu_delta = stats['cpu_stats']['cpu_usage']['total_usage'] - stats['precpu_stats']['cpu_usage']['total_usage']
            system_delta = stats['cpu_stats']['system_cpu_usage'] - stats['precpu_stats']['system_cpu_usage']
            cpu_percent = (cpu_delta / system_delta) * 100.0 if system_delta > 0 else 0

            memory_usage = stats['memory_stats']['usage']
            memory_limit = stats['memory_stats']['limit']
            memory_percent = (memory_usage / memory_limit) * 100.0

            return {
                "cpu_percent": round(cpu_percent, 2),
                "memory_usage": memory_usage,
                "memory_limit": memory_limit,
                "memory_percent": round(memory_percent, 2),
                "network_rx": stats['networks']['eth0']['rx_bytes'] if 'networks' in stats else 0,
                "network_tx": stats['networks']['eth0']['tx_bytes'] if 'networks' in stats else 0
            }
        except Exception as e:
            logger.error(f"Failed to get container stats: {e}")
            return {"error": str(e)}

    def list_containers(self, all_containers: bool = True) -> List[Dict]:
        if SIMULATE:
            return [
                {
                    "id": "simulated-id-123",
                    "name": "simulated-container",
                    "image": "nginx:alpine",
                    "status": "running",
                    "ports": {"80/tcp": [{"HostPort": "8080"}]},
                    "created": str(datetime.utcnow())
                }
            ]

        try:
            containers = self.client.containers.list(all=all_containers)
            return [
                {
                    "id": c.id,
                    "name": c.name,
                    "image": c.image.tags[0] if c.image.tags else "unknown",
                    "status": c.status,
                    "ports": c.ports,
                    "created": c.attrs['Created']
                }
                for c in containers
                if c.name.startswith(DockerConfig.get_container_prefix())
            ]
        except Exception as e:
            logger.error(f"Failed to list containers: {e}")
            return []

    def pull_image(self, image_name: str) -> Tuple[bool, str]:
        if SIMULATE:
            logger.info(f"[SIMULATED] Pulled image: {image_name}")
            return True, f"Simulated pulling {image_name}"

        try:
            self.client.images.pull(image_name)
            logger.info(f"Pulled image: {image_name}")
            return True, f"Successfully pulled {image_name}"
        except Exception as e:
            logger.error(f"Failed to pull image {image_name}: {e}")
            return False, str(e)
