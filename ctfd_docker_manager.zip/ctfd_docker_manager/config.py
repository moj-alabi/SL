import os
from flask import current_app

class DockerConfig:
    """Configuration management for Docker connections"""
    
    @staticmethod
    def init_app(app):
        """Initialize Docker configuration"""
        app.config.setdefault('DOCKER_DEFAULT_HOST', 'unix:///var/run/docker.sock')
        app.config.setdefault('DOCKER_TLS_VERIFY', False)
        app.config.setdefault('DOCKER_CERT_PATH', None)
        app.config.setdefault('DOCKER_NETWORK_NAME', 'ctfd_challenges')
        app.config.setdefault('DOCKER_CONTAINER_PREFIX', 'ctfd_')
        app.config.setdefault('DOCKER_AUTO_REMOVE', True)
        app.config.setdefault('DOCKER_MEMORY_LIMIT', '512m')
        app.config.setdefault('DOCKER_CPU_LIMIT', '0.5')
    
    @staticmethod
    def get_default_host():
        """Get default Docker host configuration"""
        return current_app.config.get('DOCKER_DEFAULT_HOST')
    
    @staticmethod
    def get_network_name():
        """Get Docker network name for challenges"""
        return current_app.config.get('DOCKER_NETWORK_NAME')
    
    @staticmethod
    def get_container_prefix():
        """Get container name prefix"""
        return current_app.config.get('DOCKER_CONTAINER_PREFIX')
    
    @staticmethod
    def get_default_limits():
        """Get default resource limits"""
        return {
            'memory': current_app.config.get('DOCKER_MEMORY_LIMIT'),
            'cpu': current_app.config.get('DOCKER_CPU_LIMIT')
        }